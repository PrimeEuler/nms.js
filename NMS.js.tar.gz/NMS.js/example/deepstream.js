//DEEPSTREAM
var KafkaMessageConnector = require('deepstream.io-msg-kafka');  // Currently there is no npm package. Coming soon!
var deepstream //= require('deepstream.io-client-js')
var Deepstream = require('deepstream.io')
var server = new Deepstream({tcpPort:6022});
var client //= deepstream('localhost:6022').login();
var msgConnector = new KafkaMessageConnector({ connectionString: 'localhost:2181' })

//server.set('messageConnector', msgConnector);
server.on('error', function(err,data){
    console.log(err,data)
    })
server.on('started', function(){
    deepstream = require('deepstream.io-client-js')
    client = deepstream('localhost:6022').login()
    client.on('error',console.log)
})
msgConnector.on('ready',function(err, data){
    console.log('Connector-Ready', err,data)
    server.start();
})
msgConnector.on('error',function(err, data){
    console.log('Connector-Error', err,data)
})
//
/*
msgConnector._consumer.on('message', function(message){
    message.value = JSON.parse( message.value )
    console.log('\r\n' + util.inspect(message,false, 10, true) + '\r\n')
})
*/
server.start();
