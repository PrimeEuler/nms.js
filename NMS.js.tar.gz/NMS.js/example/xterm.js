var shellServer     = require('../lib/shellServer'),
    util            = require('util'),
    os            = require('os'),
    ssh             = require('ssh2'),
    fs              = require('fs');
var sheldon          = require('../lib/sheldon/lib/sheldon.0.0.54.js');

var deepstream = require('deepstream.io-client-js')
var client = deepstream('localhost:6022').login()
    client.on('error',console.log)

//global.client = client



    //TERMINAL SERVICES
    /*
    tsLineType
        { 'OBJECT-TYPE':                                                                
           { SYNTAX:                                                                    
              [ 'INTEGER',                                                              
                { '1': 'unknown',                                                       
                  '2': 'console',                                                       
                  '3': 'terminal',                                                      
                  '4': 'line-printer',                                                  
                  '5': 'virtual-terminal',                                              
                  '6': 'auxiliary' } ],                                                 
             ACCESS: 'read-only',                                                       
             STATUS: 'mandatory',                                                       
             DESCRIPTION: [ 'Type of line.' ],                                          
             '::=': [ 'ltsLineEntry', 2 ] } }
     
    tslineSesType:                                                          
         { 'OBJECT-TYPE':                                                       
            { SYNTAX:                                                           
               [ 'INTEGER',                                                     
                 { '1': 'unknown',                                              
                   '2': 'pad',                                                  
                   '3': 'stream',                                               
                   '4': 'rlogin',                                               
                   '5': 'telnet',                                               
                   '6': 'tcp',                                                  
                   '7': 'lat',                                                  
                   '8': 'mop',                                                  
                   '9': 'slip',                                                 
                   '10': 'xremote',                                             
                   '11': 'rshell' } ]
            }
         }
    */
var terminalServer  = new shellServer();
var ltsLineSessionTable = { ltsLineSessionEntry:[]}
var tslineSesLine = 0;
var tslineSesSession = 0
var ltsLineSessionEntry = client.record.getRecord('localhost:8444/ltsLineSessionTable.ltsLineSessionEntry')

terminalServer.on('connection', function (socket) {

        tslineSesLine++;
        var LtsLineEntry = { SEQUENCE:                                                                     
                               [ [ 'tsLineActive', 'INTEGER' ],                                             
                                 [ 'tsLineType', 'INTEGER' ],                                          
                                 [ 'tsLineAutobaud', 'INTEGER' ],                                           
                                 [ 'tsLineSpeedin', 'INTEGER' ],                                            
                                 [ 'tsLineSpeedout', 'INTEGER' ],                                           
                                 [ 'tsLineFlow', 'INTEGER' ],                                               
                                 [ 'tsLineModem', 'INTEGER' ],                                              
                                 [ 'tsLineLoc', 'DisplayString' ],                                          
                                 [ 'tsLineTerm', 'DisplayString' ],                                         
                                 [ 'tsLineScrlen', 'INTEGER' ],                                             
                                 [ 'tsLineScrwid', 'INTEGER' ],                                             
                                 [ 'tsLineEsc', 'DisplayString' ],                                          
                                 [ 'tsLineTmo', 'INTEGER' ],                                                
                                 [ 'tsLineSestmo', 'INTEGER' ],                                             
                                 [ 'tsLineRotary', 'INTEGER' ],                                             
                                 [ 'tsLineUses', 'INTEGER' ],                                               
                                 [ 'tsLineNses', 'INTEGER' ],                                               
                                 [ 'tsLineUser', 'DisplayString' ],                                         
                                 [ 'tsLineNoise', 'INTEGER' ],                                              
                                 [ 'tsLineNumber', 'INTEGER' ],                                             
                                 [ 'tsLineTimeActive', 'INTEGER' ] ] }
        
        LtsLineEntry.SEQUENCE[0][2] = 'true (1)'            //tsLineActive                         
        LtsLineEntry.SEQUENCE[1][2] = 'virtual-terminal (5)'//tsLineType 
        LtsLineEntry.SEQUENCE[2][2] = 'true (1)'            //tsLineAutobaud 
        LtsLineEntry.SEQUENCE[3][2] = '1900'                //tsLineSpeedin 
        LtsLineEntry.SEQUENCE[4][2] = '1900'                //tsLineSpeedout 
        LtsLineEntry.SEQUENCE[5][2] = 'software-both (5)'   //tsLineFlow 
        LtsLineEntry.SEQUENCE[6][2] = 'call-in (3)'         //tsLineModem 
        LtsLineEntry.SEQUENCE[7][2] = 'virtual-port'        //tsLineLoc 
        LtsLineEntry.SEQUENCE[8][2] = 'vt100'               //tsLineTerm   
        LtsLineEntry.SEQUENCE[9][2] = 24                    //tsLineScrlen 
        LtsLineEntry.SEQUENCE[10][2] = 80                   //tsLineScrwid 
        LtsLineEntry.SEQUENCE[11][2] = 'ctrl-c'             //tsLineEsc 
        LtsLineEntry.SEQUENCE[12][2] = 30                   //tsLineTmo
        LtsLineEntry.SEQUENCE[13][2] = 30                   //tsLineSestmo 
        LtsLineEntry.SEQUENCE[14][2] = 1                    //tsLineRotary 
        LtsLineEntry.SEQUENCE[15][2] = 0                    //tsLineUses 
        LtsLineEntry.SEQUENCE[16][2] = 0                    //tsLineNses 
        LtsLineEntry.SEQUENCE[17][2] = 'root'               //tsLineUser 
        LtsLineEntry.SEQUENCE[18][2] = 0                    //tsLineNoise 
        LtsLineEntry.SEQUENCE[19][2] = tslineSesLine        //tsLineNumber
                                     
        
        socket.on('TERMINAL', function(stream){
            tslineSesSession++;
            LtsLineEntry.SEQUENCE[14][2]++;
            LtsLineEntry.SEQUENCE[15][2]++;
            
            stream.on('close',function(){
                LtsLineEntry.SEQUENCE[15][2]--;
            })
            
            var LtsLineSessionEntry_MIB = { SEQUENCE:                                                                     
                                           [ [ 'tslineSesType', 'INTEGER' ],                                            
                                             [ 'tslineSesDir', 'INTEGER' ],                                             
                                             [ 'tslineSesAddr', 'IpAddress' ],                                          
                                             [ 'tslineSesName', 'DisplayString' ],                                      
                                             [ 'tslineSesCur', 'INTEGER' ],                                             
                                             [ 'tslineSesIdle', 'INTEGER' ],                                            
                                             [ 'tslineSesLine', 'INTEGER' ],                                            
                                             [ 'tslineSesSession', 'INTEGER' ] ] }  
            
            var LtsLineSessionEntry = {
                tslineSesType   : 'stream',
                tslineSesDir    : 'incoming',
                tslineSesAddr   : '127.0.0.1',
                tslineSesName   : stream.id,
                tslineSesCur    : true,
                tslineSesIdle   : 0,
                tslineSesLine   : LtsLineEntry.tsLineNumber,
                tslineSesSession: tslineSesSession
            }
              
            var index =  LtsLineSessionEntry.tslineSesLine + ',' + LtsLineSessionEntry.tslineSesSession
            
            
            
            socket.on(stream.id, function(e){
                stream.emit(e.event,e.data)
            });
            stream.on('socket.io',function(e){
                socket.emit(stream.id,e)
            })
            
            
            
            var webshell = new sheldon( { input:stream , output:stream } );
                webshell.context.ssh = function(host,username,password){
                                    var client = new ssh.Client();
                                    var params = {
                                        host:host.split(':')[0],
                                        port:host.split(':')[1],
                                        username:username,
                                        password:password
                                    }
                                    client.connect(params);
                                    client.on('error', webshell.inspect);
                                    client.on('ready', openShell);
                                    client.on('end', client.destroy);
                                    function openShell(){
                                        client.shell(connect);
                                    }
                                    function connect(error,sshStream){
                                        webshell.connect(sshStream.stdin, sshStream.stdout, error)
                                        //sshStream.pipe(shelly.output).pipe(sshStream)
                                        /*NMS.vty.attach( { 
                                            stdin:sshStream, 
                                            stdout:sshStream 
                                            
                                        }, error )
                                        */
                                    }
                                    return('connecting to ' + host);
                            };
                webshell.context.Date = Date
            
            ltsLineSessionEntry.subscribe( function(data){
                webshell.output.write( webshell.parser.mini.generate(data) )
            })
            var index =  LtsLineEntry.SEQUENCE[19][2] + ':' + tslineSesSession 
            ltsLineSessionEntry.set( index, LtsLineSessionEntry.SEQUENCE )


        })
})
//terminalServer.listen({port:8444});

var context = {
    os:os,
    terminalServer:terminalServer
}

var shelly = new sheldon( { input: process.stdin, output: process.stdout, context:context } )


shelly.context.ssh = function(host,username,password){
                    var client = new ssh.Client();
                    var params = {
                        host:host.split(':')[0],
                        port:host.split(':')[1],
                        username:username,
                        password:password
                    }
                    client.connect(params);
                    client.on('error', shelly.inspect);
                    client.on('ready', openShell);
                    client.on('end', client.destroy);
                    function openShell(){
                        client.shell(connect);
                    }
                    function connect(error,sshStream){
                        shelly.connect(sshStream.stdin, sshStream.stdout, error)
                        //sshStream.pipe(shelly.output).pipe(sshStream)
                        /*NMS.vty.attach( { 
                            stdin:sshStream, 
                            stdout:sshStream 
                            
                        }, error )
                        */
                    }
                    return('connecting to ' + host);
            }



