var nms = require('../')
var NMS = new nms(process.stdin, process.stdout)