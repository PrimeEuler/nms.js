var shellServer     = require('../lib/shellServer'),
    deepstream = require('deepstream.io-client-js'),
    client = deepstream('localhost:6022').login(),
    SerialPort = {},//require("serialport"),
    nms             = require('../'),
    util            = require('util'),
    fs          = require('fs'),
    requirejs       = require("requirejs");
    requirejs.config({
        baseUrl: __dirname + '/ace/',
        nodeRequire: require
    })
    var ace         = requirejs('document');
    var webNMS      = new shellServer();
    //var MODULES = JSON.parse(fs.readFileSync('../lib/mib/lib/RFC_BASE_MINIMUM.JSON'))
    var browser     = require('../lib/mib/lib/browser.js');
    
    
    
    
    var localhost = client.record.getRecord('systems/localhost')
    client.on('error',console.log)
    
    localhost.on('error',console.log)
    webNMS.on('connection', function (socket) {
        
        socket.on('TERMINAL', function(stream){
                //hack for socket.io-stream events client bind
                socket.on(stream.id, function(e){
                    stream.emit(e.event,e.data)
                });
                stream.on('socket.io',function(e){
                    //console.log(e)
                    socket.emit(stream.id,e)
                })
                stream.on('resize',function(size){
                    stream.rows = size.rows;
                    stream.columns = size.cols;
                })
                var NMS = new nms(stream);
                
                localhost.subscribe( NMS.cli.inspect)
                localhost.on('error', NMS.cli.inspect)
                
                NMS.context.nms.COM = {
                    list : function(){
                        SerialPort.list( function(err, ports){
                            NMS.cli.inspect(ports)
                        })
                    },
                    open : function (comName){
                        //var port = new SerialPortStream(comName, { baudRate : 9600 });
                        var port = new SerialPort(comName, { baudRate : 9600 });
                        console.log(port)
                        function onData(data){
                            port.write(data)
                        }
                        port.on('open', function() {
                                NMS.vty.close();
                                NMS.vty.stdin.on('data',onData)
                                //port.write('\r\n')
                        });
                        port.on('data',function(data){
                            NMS.vty.stdout.write(data)
                        })
                        port.on('close',function(){
                            port.removeAllListeners()
                            NMS.vty.stdin.removeListener('data',onData)
                            NMS.vty.open()
                            
                            })
                        port.on('error',NMS.cli.inspect)
                        port.on('disconnect', function(error){
                            
                        })
                    }
                }
                NMS.context.nms.browser = browser
                NMS.context.nms.MIB = {
                    'varBinds':[
                        {   IpAddress:'127.0.0.1', 
                            CommunityString:'public',
                            varBind: {
                                'iso.org.dod.internet.mgmt.mib-2.system.sysName.0': NMS.context.os.hostname
                            }
                        },
                    ]
                }
                NMS.context.nms.edit = function(path){
                        function evalInContext(js, context) {
    //# Return the results of the in-line anonymous function we .call with the passed context
                            return function() { return eval(js); }.call(context);
                        }
                        var editStream = webNMS.createStream({objectMode: true})
                        socket.on(editStream.id, function(e){
                            editStream.emit(e.event,e.data)
                        });
                        var ACE = new ace.Document('');
                        editStream.setEncoding('utf8');
                        socket.emit('EDITOR', editStream );
                        editStream.on('data',function(data){
                            //console.log(data)
                            if(data.version > ACE.version){
                                ACE.setByAPI = true;
                                ACE.applyDeltas([data.data]);
                                ACE.setByAPI = false;
                            }
                        })
                        editStream.on('save',function(){
                            //evalInContext( ACE.getValue() ,  NMS.context)
                            var code =  ACE.getValue()
                                //NMS.cli.inspect(code);
                                
                                try{
                                    eval('NMS.context.' + code)
                                    var _path = code.split('=')[0].split(' ')[0];
                                    //var ob = NMS._.get(NMS.context, _path);
                                    NMS.cli.inspect({save:true, path:_path});
                                    NMS.cli.prompt();
                                    //console.log(code)
                                }catch(e){
                                    NMS.cli.inspect(e)
                                }
                        })
                        editStream.on('share',function(){
                            NMS.cli.inspect({share:true, id:editStream.id});
                            NMS.cli.prompt();
                        })
                        
                        ACE.version = 0;
                        ACE.on('change', function (delta){
                            
                            if (!ACE.setByAPI) {
                                ACE.version++;
                                delta.version = ACE.version;
                                editStream.write(delta)
                                //console.log(delta)
                            }
                        });
                        var contents =  NMS._.get(NMS.context, path);
                        
                        switch(typeof contents){
                            case 'object':
                                contents =  path + ' = ' + util.inspect(contents, false,null);
                                break;
                            case 'function':
                                contents =  path + ' = ' + contents.toString();
                                break;
                            case 'undefined':
                                break;
                            case 'symbol':
                            case 'boolean':
                            case 'number':   
                            case 'string':
                            default:
                                contents =  path + ' = ' + contents.toString();
                                break;
        
                        }
                        //console.log(contents)
                        ACE.insert({ row: 0, column: 0},   contents );
                    },
                NMS.context.ds = client   
                NMS.context.localhost =  {
                    get: function(path){
                        return localhost.get( path)
                    },
                    set: function (path, value){

                        localhost.set(path, value )
                        return ''
                    }
                }
                
            })
        

    });
    webNMS.listen({port:8443});
