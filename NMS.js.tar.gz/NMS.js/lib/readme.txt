nohup ~/kafka/bin/kafka-server-start.sh ~/kafka/config/server.properties > ~/kafka/kafka.log 2>&1 &

~/kafka/bin/kafka-topics.sh --delete --zookeeper localhost:2181 --topic your_topic_name
