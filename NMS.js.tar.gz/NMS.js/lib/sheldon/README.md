sheldon
======
What is sheldon?:
======
Sheldon is a node.js unix-like shell based on Sheldon from U.S. Acres
